import { a as require_react, o as __toESM, t as require_jsx_runtime } from "../index.js";
//#region app/report-export.ts
var import_react = /* @__PURE__ */ __toESM(require_react(), 1);
function save(blob, filename) {
	const url = URL.createObjectURL(blob);
	const link = document.createElement("a");
	link.href = url;
	link.download = filename;
	link.click();
	setTimeout(() => URL.revokeObjectURL(url), 1e3);
}
var filename = (value) => value.normalize("NFD").replace(/[\u0300-\u036f]/g, "").replace(/[^a-zA-Z0-9]+/g, "-").replace(/^-|-$/g, "").toLowerCase();
var xml = (value) => String(value ?? "").replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;").replace(/"/g, "&quot;");
var dateLabel = (value) => new Date(value).toLocaleString("pt-BR", {
	dateStyle: "short",
	timeStyle: "short"
});
function totals(activities) {
	const protocols = activities.filter((item) => item.kind === "protocol").reduce((sum, item) => sum + item.quantity, 0);
	const calls = activities.filter((item) => item.kind === "call").reduce((sum, item) => sum + item.quantity, 0);
	const types = /* @__PURE__ */ new Map();
	activities.forEach((item) => types.set(item.typologyName, (types.get(item.typologyName) ?? 0) + item.quantity));
	return {
		protocols,
		calls,
		total: protocols + calls,
		types: [...types].sort((a, b) => b[1] - a[1])
	};
}
function exportExcelReport(options) {
	const sum = totals(options.activities);
	const records = options.activities.map((item) => `<Row><Cell><Data ss:Type="String">${xml(item.userName)}</Data></Cell><Cell><Data ss:Type="String">${xml(item.userEmail)}</Data></Cell><Cell><Data ss:Type="String">${item.kind === "protocol" ? "Protocolo" : "Ligação"}</Data></Cell><Cell><Data ss:Type="String">${xml(item.distributionState || "-")}</Data></Cell><Cell><Data ss:Type="String">${xml(item.protocol || "-")}</Data></Cell><Cell><Data ss:Type="String">${xml(item.typologyName)}</Data></Cell><Cell ss:StyleID="Number"><Data ss:Type="Number">${item.quantity}</Data></Cell><Cell><Data ss:Type="String">${xml(dateLabel(item.occurredAt))}</Data></Cell></Row>`).join("");
	const types = sum.types.map(([name, count]) => `<Row><Cell><Data ss:Type="String">${xml(name)}</Data></Cell><Cell ss:StyleID="Number"><Data ss:Type="Number">${count}</Data></Cell></Row>`).join("");
	const book = `<?xml version="1.0" encoding="UTF-8"?><?mso-application progid="Excel.Sheet"?><Workbook xmlns="urn:schemas-microsoft-com:office:spreadsheet" xmlns:ss="urn:schemas-microsoft-com:office:spreadsheet"><Styles><Style ss:ID="Default"><Font ss:FontName="Aptos" ss:Size="11"/><Alignment ss:Vertical="Center"/></Style><Style ss:ID="Title"><Font ss:Size="20" ss:Bold="1" ss:Color="#FFFFFF"/><Interior ss:Color="#0B1828" ss:Pattern="Solid"/></Style><Style ss:ID="Subtitle"><Font ss:Color="#DCE9FA"/><Interior ss:Color="#0B1828" ss:Pattern="Solid"/></Style><Style ss:ID="Header"><Font ss:Bold="1" ss:Color="#111111"/><Interior ss:Color="#F2B705" ss:Pattern="Solid"/></Style><Style ss:ID="Metric"><Font ss:Size="16" ss:Bold="1" ss:Color="#FFFFFF"/><Interior ss:Color="#203149" ss:Pattern="Solid"/><Alignment ss:Horizontal="Center"/></Style><Style ss:ID="Number"><NumberFormat ss:Format="#,##0"/><Alignment ss:Horizontal="Center"/></Style></Styles>
  <Worksheet ss:Name="Resumo"><Table><Column ss:Width="280"/><Column ss:Width="110"/><Column ss:Width="110"/><Column ss:Width="110"/><Row ss:Height="36"><Cell ss:StyleID="Title" ss:MergeAcross="3"><Data ss:Type="String">${xml(options.title)}</Data></Cell></Row><Row ss:Height="24"><Cell ss:StyleID="Subtitle" ss:MergeAcross="3"><Data ss:Type="String">${xml(options.subtitle)}</Data></Cell></Row><Row/><Row><Cell/><Cell ss:StyleID="Header"><Data ss:Type="String">Protocolos</Data></Cell><Cell ss:StyleID="Header"><Data ss:Type="String">Ligações</Data></Cell><Cell ss:StyleID="Header"><Data ss:Type="String">Total</Data></Cell></Row><Row ss:Height="32"><Cell/><Cell ss:StyleID="Metric"><Data ss:Type="Number">${sum.protocols}</Data></Cell><Cell ss:StyleID="Metric"><Data ss:Type="Number">${sum.calls}</Data></Cell><Cell ss:StyleID="Metric"><Data ss:Type="Number">${sum.total}</Data></Cell></Row><Row/><Row><Cell ss:StyleID="Header"><Data ss:Type="String">Tipologia</Data></Cell><Cell ss:StyleID="Header"><Data ss:Type="String">Quantidade</Data></Cell></Row>${types}</Table></Worksheet>
  <Worksheet ss:Name="Registros"><Table><Column ss:Width="150"/><Column ss:Width="200"/><Column ss:Width="80"/><Column ss:Width="70"/><Column ss:Width="110"/><Column ss:Width="260"/><Column ss:Width="70"/><Column ss:Width="120"/><Row ss:Height="32"><Cell ss:StyleID="Title" ss:MergeAcross="7"><Data ss:Type="String">Registros detalhados</Data></Cell></Row><Row><Cell ss:StyleID="Header"><Data ss:Type="String">Atendente</Data></Cell><Cell ss:StyleID="Header"><Data ss:Type="String">E-mail</Data></Cell><Cell ss:StyleID="Header"><Data ss:Type="String">Tipo</Data></Cell><Cell ss:StyleID="Header"><Data ss:Type="String">Estado</Data></Cell><Cell ss:StyleID="Header"><Data ss:Type="String">Protocolo</Data></Cell><Cell ss:StyleID="Header"><Data ss:Type="String">Tipologia</Data></Cell><Cell ss:StyleID="Header"><Data ss:Type="String">Quantidade</Data></Cell><Cell ss:StyleID="Header"><Data ss:Type="String">Data e hora</Data></Cell></Row>${records}</Table></Worksheet></Workbook>`;
	save(new Blob([book], { type: "application/vnd.ms-excel;charset=utf-8" }), `relatorio-arii-${filename(options.subtitle)}.xls`);
}
var pdfText = (value) => String(value ?? "").normalize("NFD").replace(/[\u0300-\u036f]/g, "").replace(/[^\x20-\x7E]/g, "").replace(/\\/g, "\\\\").replace(/\(/g, "\\(").replace(/\)/g, "\\)");
var short = (value, length) => {
	const text = pdfText(value);
	return text.length > length ? `${text.slice(0, length - 3)}...` : text;
};
function exportPdfReport(options) {
	const sum = totals(options.activities);
	const perPage = 20;
	const pages = options.activities.length ? Array.from({ length: Math.ceil(options.activities.length / perPage) }, (_, i) => options.activities.slice(i * perPage, (i + 1) * perPage)) : [[]];
	const streams = pages.map((items, page) => {
		const c = [
			"0.043 0.094 0.157 rg 0 0 595 842 re f",
			"0.949 0.718 0.020 rg 0 778 595 64 re f",
			`BT /F2 20 Tf 0.06 0.06 0.06 rg 34 807 Td (ARII | ${pdfText(options.title)}) Tj ET`,
			`BT /F1 9 Tf 0.12 0.18 0.25 rg 34 790 Td (${pdfText(options.subtitle)} | ${pdfText((/* @__PURE__ */ new Date()).toLocaleString("pt-BR"))}) Tj ET`,
			"0.125 0.192 0.286 rg 34 716 165 45 re f 215 716 165 45 re f 396 716 165 45 re f",
			`BT /F1 8 Tf 0.68 0.76 0.86 rg 48 744 Td (PROTOCOLOS) Tj 181 0 Td (LIGACOES) Tj 181 0 Td (TOTAL) Tj ET`,
			`BT /F2 18 Tf 1 1 1 rg 48 724 Td (${sum.protocols}) Tj 181 0 Td (${sum.calls}) Tj 181 0 Td (${sum.total}) Tj ET`,
			"0.949 0.718 0.020 rg 34 680 527 26 re f",
			"BT /F2 8 Tf 0.06 0.06 0.06 rg 40 689 Td (ATENDENTE) Tj 120 0 Td (TIPO / UF) Tj 100 0 Td (PROTOCOLO) Tj 92 0 Td (TIPOLOGIA) Tj 150 0 Td (QTD) Tj ET"
		];
		items.forEach((item, i) => {
			const y = 660 - i * 28;
			if (i % 2 === 0) c.push(`0.067 0.133 0.216 rg 34 ${y - 7} 527 25 re f`);
			c.push(`BT /F1 7.5 Tf 0.9 0.94 0.98 rg 40 ${y} Td (${short(item.userName, 25)}) Tj 120 0 Td (${item.kind === "protocol" ? "Protocolo" : "Ligacao"} / ${pdfText(item.distributionState || "-")}) Tj 100 0 Td (${short(item.protocol || "-", 16)}) Tj 92 0 Td (${short(item.typologyName, 27)}) Tj 150 0 Td (${item.quantity}) Tj ET`);
		});
		c.push(`BT /F1 8 Tf 0.55 0.65 0.76 rg 34 34 Td (Backoffice Producao - Relatorio operacional) Tj 445 0 Td (Pagina ${page + 1}/${pages.length}) Tj ET`);
		return c.join("\n");
	});
	const regular = 3 + streams.length * 2, bold = regular + 1;
	const objects = ["<< /Type /Catalog /Pages 2 0 R >>", `<< /Type /Pages /Count ${streams.length} /Kids [${streams.map((_, i) => `${3 + i * 2} 0 R`).join(" ")}] >>`];
	streams.forEach((stream, i) => {
		objects.push(`<< /Type /Page /Parent 2 0 R /MediaBox [0 0 595 842] /Resources << /Font << /F1 ${regular} 0 R /F2 ${bold} 0 R >> >> /Contents ${4 + i * 2} 0 R >>`, `<< /Length ${stream.length} >>\nstream\n${stream}\nendstream`);
	});
	objects.push("<< /Type /Font /Subtype /Type1 /BaseFont /Helvetica >>", "<< /Type /Font /Subtype /Type1 /BaseFont /Helvetica-Bold >>");
	let pdf = "%PDF-1.4\n";
	const offsets = [0];
	objects.forEach((obj, i) => {
		offsets.push(pdf.length);
		pdf += `${i + 1} 0 obj\n${obj}\nendobj\n`;
	});
	const xref = pdf.length;
	pdf += `xref\n0 ${objects.length + 1}\n0000000000 65535 f \n${offsets.slice(1).map((n) => `${String(n).padStart(10, "0")} 00000 n `).join("\n")}\ntrailer\n<< /Size ${objects.length + 1} /Root 1 0 R >>\nstartxref\n${xref}\n%%EOF`;
	save(new Blob([pdf], { type: "application/pdf" }), `relatorio-arii-${filename(options.subtitle)}.pdf`);
}
//#endregion
//#region app/dashboard.tsx
var import_jsx_runtime = require_jsx_runtime();
var EMPTY_DATA = {
	currentUser: {
		email: "",
		name: "",
		role: "attendant",
		employeeCode: null,
		registrationComplete: false,
		isAdmin: false
	},
	typologies: [],
	activities: [],
	team: [],
	settings: {
		workdaySeconds: 20400,
		goal: .9,
		challenge: 1
	}
};
var todayInput = () => {
	const date = /* @__PURE__ */ new Date();
	const offset = date.getTimezoneOffset();
	return (/* @__PURE__ */ new Date(date.getTime() - offset * 6e4)).toISOString().slice(0, 10);
};
var timeInput = () => (/* @__PURE__ */ new Date()).toLocaleTimeString("pt-BR", {
	hour: "2-digit",
	minute: "2-digit"
});
function formatDuration(totalSeconds) {
	const seconds = Math.max(0, Math.round(totalSeconds));
	const hours = Math.floor(seconds / 3600);
	const minutes = Math.floor(seconds % 3600 / 60);
	return `${hours}h${String(minutes).padStart(2, "0")}`;
}
function formatPercent(value) {
	return `${Math.round(value * 100)}%`;
}
function kindLabel(kind) {
	return kind === "protocol" ? "Protocolo" : "Ligação";
}
function activityDate(value) {
	const [date, time] = value.split("T");
	const [year, month, day] = date.split("-");
	return `${day}/${month}/${year} • ${time?.slice(0, 5) ?? "--:--"}`;
}
function Dashboard({ authUser, accessToken }) {
	const [data, setData] = (0, import_react.useState)(EMPTY_DATA);
	const [loading, setLoading] = (0, import_react.useState)(true);
	const [error, setError] = (0, import_react.useState)("");
	const [tab, setTab] = (0, import_react.useState)("overview");
	const [menuOpen, setMenuOpen] = (0, import_react.useState)(false);
	const [search, setSearch] = (0, import_react.useState)("");
	const onSignOut = async () => {
		window.location.assign("/api/auth/logout");
	};
	const loadDashboard = (0, import_react.useCallback)(async () => {
		setLoading(true);
		setError("");
		try {
			const response = await fetch("/api/dashboard", {
				cache: "no-store",
				headers: { authorization: `Bearer ${accessToken}` }
			});
			const payload = await response.json();
			if (!response.ok) throw new Error(payload.error || "Não foi possível carregar o painel.");
			setData(payload);
		} catch (loadError) {
			setError(loadError instanceof Error ? loadError.message : "Não foi possível carregar o painel.");
		} finally {
			setLoading(false);
		}
	}, [accessToken]);
	(0, import_react.useEffect)(() => {
		const timer = window.setTimeout(() => void loadDashboard(), 0);
		return () => window.clearTimeout(timer);
	}, [loadDashboard]);
	const isSupervisor = data.currentUser.role === "supervisor";
	const navItems = isSupervisor ? [
		{
			id: "overview",
			label: "Visão geral",
			icon: "⌂"
		},
		{
			id: "records",
			label: "Protocolos e ligações",
			icon: "▤"
		},
		{
			id: "report",
			label: "Relatórios da equipe",
			icon: "▥"
		},
		{
			id: "team",
			label: "Equipe",
			icon: "◎"
		}
	] : [
		{
			id: "overview",
			label: "Visão geral",
			icon: "⌂"
		},
		{
			id: "calculator",
			label: "Calculadora",
			icon: "▦"
		},
		{
			id: "records",
			label: "Meus registros",
			icon: "▤"
		},
		{
			id: "scripts",
			label: "Scripts",
			icon: "✎"
		},
		{
			id: "report",
			label: "Meu relatório",
			icon: "▥"
		}
	];
	const today = todayInput();
	const todayActivities = (0, import_react.useMemo)(() => data.activities.filter((activity) => activity.occurredAt.startsWith(today)), [data.activities, today]);
	const todayProtocols = todayActivities.filter((activity) => activity.kind === "protocol").reduce((sum, activity) => sum + activity.quantity, 0);
	const todayCalls = todayActivities.filter((activity) => activity.kind === "call").reduce((sum, activity) => sum + activity.quantity, 0);
	const todayProductiveSeconds = todayActivities.reduce((sum, activity) => sum + activity.durationSeconds * activity.quantity, 0);
	const productivity = todayProductiveSeconds / data.settings.workdaySeconds;
	function selectTab(nextTab) {
		setTab(nextTab);
		setMenuOpen(false);
		setSearch("");
	}
	if (!loading && !error && !isSupervisor && !data.currentUser.registrationComplete) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(AccountRegistration, {
		email: data.currentUser.email || authUser.email,
		suggestedName: data.currentUser.name || authUser.displayName,
		accessToken,
		onSignOut,
		onCompleted: loadDashboard
	});
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("main", {
		className: "app-shell",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("aside", {
				className: `sidebar ${menuOpen ? "sidebar-open" : ""}`,
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "brand",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "brand-mark",
							children: "A"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("strong", { children: "ARII" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("small", { children: "Produtividade" })] })]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("nav", {
						"aria-label": "Navegação principal",
						children: navItems.map((item) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
							className: tab === item.id ? "nav-item active" : "nav-item",
							onClick: () => selectTab(item.id),
							type: "button",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "nav-icon",
								"aria-hidden": "true",
								children: item.icon
							}), item.label]
						}, item.id))
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "sidebar-footer",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: `role-chip ${isSupervisor ? "supervisor" : "attendant"}`,
							children: isSupervisor ? "Supervisão • leitura" : "Atendente"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("small", { children: data.currentUser.email || authUser.email })]
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
				className: "workspace",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("header", {
					className: "topbar",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
							className: "menu-button",
							type: "button",
							onClick: () => setMenuOpen(!menuOpen),
							"aria-label": "Abrir menu",
							children: "☰"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("h1", { children: [
							"Controle de Produtividade ",
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "•" }),
							" Backoffice"
						] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", { children: isSupervisor ? "Acompanhamento da equipe" : "Meus protocolos e ligações" })] }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "topbar-user",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "today-label",
									children: (/* @__PURE__ */ new Date()).toLocaleDateString("pt-BR", {
										day: "2-digit",
										month: "long",
										year: "numeric"
									})
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
									className: "avatar",
									"aria-hidden": "true",
									children: (data.currentUser.name || authUser.displayName).charAt(0).toUpperCase()
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
									type: "button",
									className: "signout signout-button",
									onClick: () => void onSignOut(),
									children: "Sair"
								})
							]
						})
					]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "content",
					children: [
						error ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "alert error",
							children: [error, /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
								onClick: () => void loadDashboard(),
								children: "Tentar novamente"
							})]
						}) : null,
						loading ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(LoadingState, {}) : null,
						!loading && !error ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [
							tab === "overview" && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Overview, {
								isSupervisor,
								data,
								productivity,
								todayProtocols,
								todayCalls,
								todayProductiveSeconds,
								onSaved: loadDashboard,
								accessToken
							}),
							tab === "calculator" && !isSupervisor && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Calculator, { data }),
							tab === "scripts" && !isSupervisor && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Scripts, {}),
							tab === "records" && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Records, {
								activities: data.activities,
								typologies: data.typologies,
								search,
								setSearch,
								isSupervisor,
								accessToken,
								onChanged: loadDashboard
							}),
							tab === "report" && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Report, {
								data,
								isSupervisor
							}),
							tab === "team" && isSupervisor && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Team, { data })
						] }) : null
					]
				})]
			}),
			menuOpen ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
				className: "menu-backdrop",
				"aria-label": "Fechar menu",
				onClick: () => setMenuOpen(false)
			}) : null
		]
	});
}
function AccountRegistration({ email, suggestedName, accessToken, onSignOut, onCompleted }) {
	const [name, setName] = (0, import_react.useState)(suggestedName);
	const [employeeCode, setEmployeeCode] = (0, import_react.useState)("");
	const [status, setStatus] = (0, import_react.useState)({
		type: "idle",
		message: ""
	});
	async function submit(event) {
		event.preventDefault();
		setStatus({
			type: "saving",
			message: "Criando seu cadastro..."
		});
		try {
			const response = await fetch("/api/account", {
				method: "POST",
				headers: {
					"content-type": "application/json",
					authorization: `Bearer ${accessToken}`
				},
				body: JSON.stringify({
					name,
					employeeCode
				})
			});
			const result = await response.json();
			if (!response.ok) throw new Error(result.error || "Não foi possível concluir o cadastro.");
			await onCompleted();
		} catch (submitError) {
			setStatus({
				type: "error",
				message: submitError instanceof Error ? submitError.message : "Não foi possível concluir o cadastro."
			});
		}
	}
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("main", {
		className: "registration-shell",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
			className: "registration-card",
			"aria-labelledby": "registration-title",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "registration-heading",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "brand-mark",
						children: "A"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "eyebrow",
						children: "PRIMEIRO ACESSO"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
						id: "registration-title",
						children: "Crie seu cadastro de atendente"
					})] })]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "registration-copy",
					children: "Preencha seus dados uma única vez. Depois você terá acesso à calculadora, aos seus registros e ao seu relatório individual."
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("form", {
					className: "activity-form",
					onSubmit: submit,
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
							className: "field",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "Nome completo" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
								value: name,
								onChange: (event) => setName(event.target.value),
								minLength: 3,
								maxLength: 120,
								required: true
							})]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
							className: "field",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "E-mail de acesso" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
								value: email,
								readOnly: true,
								"aria-readonly": "true"
							})]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
							className: "field",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "Matrícula ou identificação" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
								value: employeeCode,
								onChange: (event) => setEmployeeCode(event.target.value),
								minLength: 2,
								maxLength: 40,
								placeholder: "Ex.: 123456",
								required: true
							})]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
							className: "primary-button",
							type: "submit",
							disabled: status.type === "saving",
							children: status.type === "saving" ? "Criando cadastro..." : "Concluir meu cadastro"
						}),
						status.message ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: `form-status ${status.type}`,
							children: status.message
						}) : null
					]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					className: "registration-exit registration-exit-button",
					type: "button",
					onClick: () => void onSignOut(),
					children: "Sair e usar outra conta"
				})
			]
		})
	});
}
function LoadingState() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: "loading-grid",
		"aria-label": "Carregando painel",
		children: [
			1,
			2,
			3,
			4
		].map((item) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "skeleton" }, item))
	});
}
function Overview({ isSupervisor, data, productivity, todayProtocols, todayCalls, todayProductiveSeconds, onSaved, accessToken }) {
	const teamProductivity = data.team.length ? data.team.reduce((sum, member) => sum + member.productiveSeconds, 0) / (data.settings.workdaySeconds * data.team.length) : 0;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "page-stack",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("section", {
			className: "metric-grid",
			children: (isSupervisor ? [
				{
					label: "Atendentes",
					value: String(data.team.length),
					icon: "◎",
					tone: "blue"
				},
				{
					label: "Protocolos registrados",
					value: String(data.activities.filter((a) => a.kind === "protocol").reduce((s, a) => s + a.quantity, 0)),
					icon: "▤",
					tone: "blue"
				},
				{
					label: "Ligações registradas",
					value: String(data.activities.filter((a) => a.kind === "call").reduce((s, a) => s + a.quantity, 0)),
					icon: "◖",
					tone: "green"
				},
				{
					label: "Produtividade da equipe",
					value: formatPercent(teamProductivity),
					icon: "↗",
					tone: "green"
				}
			] : [
				{
					label: "Produtividade hoje",
					value: formatPercent(productivity),
					icon: "↗",
					tone: "green"
				},
				{
					label: "Protocolos hoje",
					value: String(todayProtocols),
					icon: "▤",
					tone: "blue"
				},
				{
					label: "Ligações hoje",
					value: String(todayCalls),
					icon: "◖",
					tone: "blue"
				},
				{
					label: "Tempo produtivo",
					value: formatDuration(todayProductiveSeconds),
					icon: "◷",
					tone: "green"
				}
			]).map((card) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("article", {
				className: "metric-card",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
					className: `metric-icon ${card.tone}`,
					children: card.icon
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("small", { children: card.label }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("strong", { children: card.value })] })]
			}, card.label))
		}), isSupervisor ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "dashboard-grid supervisor-grid",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TeamSummary, {
				data,
				compact: true
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(RecentActivities, {
				activities: data.activities,
				supervisor: true
			})]
		}) : /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "dashboard-grid",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ActivityForm, {
				typologies: data.typologies,
				onSaved,
				accessToken
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(RecentActivities, { activities: data.activities })]
		})]
	});
}
function ActivityForm({ typologies, onSaved, accessToken }) {
	const [kind, setKind] = (0, import_react.useState)("protocol");
	const [protocol, setProtocol] = (0, import_react.useState)("");
	const [typologyId, setTypologyId] = (0, import_react.useState)(typologies[0]?.id ?? 0);
	const [date, setDate] = (0, import_react.useState)(todayInput());
	const [time, setTime] = (0, import_react.useState)(timeInput());
	const [quantity, setQuantity] = (0, import_react.useState)(1);
	const [distributionState, setDistributionState] = (0, import_react.useState)("PA");
	const [status, setStatus] = (0, import_react.useState)({
		type: "idle",
		message: ""
	});
	const selectedTypologyId = typologyId || typologies[0]?.id || 0;
	async function submit(event) {
		event.preventDefault();
		setStatus({
			type: "saving",
			message: "Salvando registro..."
		});
		try {
			const response = await fetch("/api/activities", {
				method: "POST",
				headers: {
					"content-type": "application/json",
					authorization: `Bearer ${accessToken}`
				},
				body: JSON.stringify({
					kind,
					protocol,
					typologyId: selectedTypologyId,
					date,
					time,
					quantity,
					distributionState
				})
			});
			const result = await response.json();
			if (!response.ok) throw new Error(result.error || "Não foi possível salvar.");
			setStatus({
				type: "success",
				message: result.message || "Registro salvo."
			});
			setProtocol("");
			setQuantity(1);
			await onSaved();
		} catch (submitError) {
			setStatus({
				type: "error",
				message: submitError instanceof Error ? submitError.message : "Não foi possível salvar."
			});
		}
	}
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
		className: "panel register-panel",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "section-heading",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "eyebrow",
					children: "NOVO REGISTRO"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", { children: "Registrar atividade" })] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
					className: "permission-tag",
					children: "Seu acesso"
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "kind-toggle",
				role: "group",
				"aria-label": "Tipo de atividade",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					type: "button",
					className: kind === "protocol" ? "selected" : "",
					onClick: () => setKind("protocol"),
					children: "Protocolo"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					type: "button",
					className: kind === "call" ? "selected" : "",
					onClick: () => setKind("call"),
					children: "Ligação"
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("form", {
				onSubmit: submit,
				className: "activity-form",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
						className: "field",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "Tipologia" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("select", {
							value: selectedTypologyId,
							onChange: (event) => setTypologyId(Number(event.target.value)),
							required: true,
							children: typologies.map((item) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
								value: item.id,
								children: item.name
							}, item.id))
						})]
					}),
					kind === "protocol" ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
						className: "field",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "Número do protocolo" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
							value: protocol,
							onChange: (event) => setProtocol(event.target.value),
							placeholder: "Ex.: PC-5821",
							required: true
						})]
					}) : null,
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
						className: "field",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "Estado atendido" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("select", {
							value: distributionState,
							onChange: (event) => setDistributionState(event.target.value),
							required: true,
							children: Object.entries(STATE_CONTACTS).map(([code, item]) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
								value: code,
								children: item.state
							}, code))
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "form-row three",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
								className: "field",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "Data" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
									type: "date",
									value: date,
									onChange: (event) => setDate(event.target.value),
									required: true
								})]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
								className: "field",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "Hora" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
									type: "time",
									value: time,
									onChange: (event) => setTime(event.target.value),
									required: true
								})]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
								className: "field",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "Quantidade" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
									type: "number",
									min: "1",
									max: "9999",
									value: quantity,
									onChange: (event) => setQuantity(Number(event.target.value)),
									required: true
								})]
							})
						]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						className: "primary-button",
						type: "submit",
						disabled: status.type === "saving",
						children: status.type === "saving" ? "Salvando..." : "Salvar meu registro"
					}),
					status.message ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: `form-status ${status.type}`,
						children: status.message
					}) : null
				]
			})
		]
	});
}
function RecentActivities({ activities, supervisor = false }) {
	const recent = activities.slice(0, 8);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
		className: "panel recent-panel",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "section-heading",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "eyebrow",
				children: "ATUALIZAÇÃO AUTOMÁTICA"
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", { children: supervisor ? "Últimos registros da equipe" : "Meus últimos registros" })] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
				className: "live-dot",
				children: "Ao vivo"
			})]
		}), recent.length ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "activity-list",
			children: recent.map((activity) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("article", {
				className: "activity-item",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: `kind-badge ${activity.kind}`,
						children: activity.kind === "protocol" ? "P" : "L"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "activity-main",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("strong", { children: activity.protocol || kindLabel(activity.kind) }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", { children: [activity.typologyName, activity.distributionState ? ` • ${activity.distributionState}` : ""] }),
							supervisor ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("small", { children: activity.userName }) : null
						]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "activity-meta",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("strong", { children: activity.quantity }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: activityDate(activity.occurredAt) })]
					})
				]
			}, activity.id))
		}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(EmptyState, {
			title: "Nenhum registro ainda",
			text: supervisor ? "Os registros dos atendentes aparecerão aqui." : "Cadastre seu primeiro protocolo ou ligação."
		})]
	});
}
function Calculator({ data }) {
	const [quantities, setQuantities] = (0, import_react.useState)({});
	const productiveSeconds = data.typologies.reduce((sum, item) => sum + item.seconds * (quantities[item.id] || 0), 0);
	const percentage = productiveSeconds / data.settings.workdaySeconds;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "page-stack",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "page-title",
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "eyebrow",
					children: "SIMULAÇÃO INDIVIDUAL"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", { children: "Calculadora de produtividade" }),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", { children: "Informe quanto realizou de cada tipologia. A simulação não cria registros." })
			] })
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
			className: "calculator-layout",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "panel calculator-table",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "table-header",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "Tipologia" }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "Tempo padrão" }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "Quantidade" })
					]
				}), data.typologies.map((item) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "calculator-row",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: item.name }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: formatDuration(item.seconds) }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
							"aria-label": `Quantidade de ${item.name}`,
							type: "number",
							min: "0",
							value: quantities[item.id] || "",
							onChange: (event) => setQuantities((current) => ({
								...current,
								[item.id]: Math.max(0, Number(event.target.value) || 0)
							}))
						})
					]
				}, item.id))]
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("aside", {
				className: "panel calculator-result",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "eyebrow",
						children: "RESULTADO"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "score-ring",
						style: { "--score": `${Math.min(100, percentage * 100)}%` },
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("strong", { children: formatPercent(percentage) }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "produtividade" })]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "result-line",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "Tempo produtivo" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("strong", { children: formatDuration(productiveSeconds) })]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "result-line",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "Meta" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("strong", { children: "90%" })]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: `result-status ${percentage >= 1 ? "challenge" : percentage >= .9 ? "goal" : "below"}`,
						children: percentage >= 1 ? "Desafio alcançado" : percentage >= .9 ? "Meta alcançada" : "Abaixo da meta"
					})
				]
			})]
		})]
	});
}
function Records({ activities, typologies, search, setSearch, isSupervisor, accessToken, onChanged }) {
	const [kind, setKind] = (0, import_react.useState)("all");
	const [editing, setEditing] = (0, import_react.useState)(null);
	const [actionStatus, setActionStatus] = (0, import_react.useState)("");
	const [deletingId, setDeletingId] = (0, import_react.useState)(null);
	const filtered = activities.filter((activity) => {
		const matchesKind = kind === "all" || activity.kind === kind;
		const haystack = `${activity.protocol ?? ""} ${activity.typologyName} ${activity.userName} ${activity.distributionState ?? ""}`.toLowerCase();
		return matchesKind && haystack.includes(search.toLowerCase());
	});
	async function deleteActivity(activity) {
		const label = activity.protocol ? `o protocolo ${activity.protocol}` : "esta ligação";
		if (!window.confirm(`Tem certeza que deseja excluir ${label}? Esta ação não pode ser desfeita.`)) return;
		setDeletingId(activity.id);
		setActionStatus("");
		try {
			const response = await fetch(`/api/activities?id=${activity.id}`, {
				method: "DELETE",
				headers: { authorization: `Bearer ${accessToken}` }
			});
			const result = await response.json();
			if (!response.ok) throw new Error(result.error || "Não foi possível excluir o registro.");
			setActionStatus(result.message || "Registro excluído.");
			await onChanged();
		} catch (error) {
			setActionStatus(error instanceof Error ? error.message : "Não foi possível excluir o registro.");
		} finally {
			setDeletingId(null);
		}
	}
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "page-stack",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "page-title",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "eyebrow",
						children: "HISTÓRICO"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", { children: isSupervisor ? "Protocolos e ligações da equipe" : "Meus registros" }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", { children: isSupervisor ? "Consulta somente de leitura, organizada por atendente." : "Confira tudo o que você cadastrou." })
				] })
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
				className: "panel records-panel",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "filters",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
							value: search,
							onChange: (event) => setSearch(event.target.value),
							placeholder: "Buscar protocolo, tipologia ou atendente"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("select", {
							value: kind,
							onChange: (event) => setKind(event.target.value),
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
									value: "all",
									children: "Todos os tipos"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
									value: "protocol",
									children: "Protocolos"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
									value: "call",
									children: "Ligações"
								})
							]
						})]
					}),
					actionStatus ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "records-status",
						role: "status",
						children: actionStatus
					}) : null,
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ActivityTable, {
						activities: filtered,
						showUser: isSupervisor,
						onEdit: isSupervisor ? void 0 : setEditing,
						onDelete: isSupervisor ? void 0 : deleteActivity,
						deletingId
					})
				]
			}),
			editing ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(EditActivityModal, {
				activity: editing,
				typologies,
				accessToken,
				onClose: () => setEditing(null),
				onSaved: async (message) => {
					setEditing(null);
					setActionStatus(message);
					await onChanged();
				}
			}) : null
		]
	});
}
function ActivityTable({ activities, showUser, onEdit, onDelete, deletingId }) {
	if (!activities.length) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(EmptyState, {
		title: "Nada encontrado",
		text: "Ajuste os filtros ou aguarde novos registros."
	});
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: "table-scroll",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("table", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("thead", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("tr", { children: [
			showUser ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", { children: "Atendente" }) : null,
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", { children: "Tipo" }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", { children: "Estado" }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", { children: "Protocolo" }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", { children: "Tipologia" }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", { children: "Quantidade" }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", { children: "Data e hora" }),
			onEdit && onDelete ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", { children: "Ações" }) : null
		] }) }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("tbody", { children: activities.map((activity) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("tr", { children: [
			showUser ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("td", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("strong", { children: activity.userName }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("small", { children: activity.userEmail })] }) : null,
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
				className: `table-kind ${activity.kind}`,
				children: kindLabel(activity.kind)
			}) }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("strong", { children: activity.distributionState || "—" }) }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", { children: activity.protocol || "—" }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", { children: activity.typologyName }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", { children: activity.quantity }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", { children: activityDate(activity.occurredAt) }),
			onEdit && onDelete ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "record-actions",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					type: "button",
					className: "edit-action",
					onClick: () => onEdit(activity),
					children: "Editar"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					type: "button",
					className: "delete-action",
					onClick: () => onDelete(activity),
					disabled: deletingId === activity.id,
					children: deletingId === activity.id ? "Excluindo..." : "Excluir"
				})]
			}) }) : null
		] }, activity.id)) })] })
	});
}
function EditActivityModal({ activity, typologies, accessToken, onClose, onSaved }) {
	const [kind, setKind] = (0, import_react.useState)(activity.kind);
	const [protocol, setProtocol] = (0, import_react.useState)(activity.protocol || "");
	const [typologyId, setTypologyId] = (0, import_react.useState)(activity.typologyId);
	const [quantity, setQuantity] = (0, import_react.useState)(activity.quantity);
	const [date, setDate] = (0, import_react.useState)(activity.occurredAt.slice(0, 10));
	const [time, setTime] = (0, import_react.useState)(activity.occurredAt.slice(11, 16));
	const [distributionState, setDistributionState] = (0, import_react.useState)(activity.distributionState || "PA");
	const [status, setStatus] = (0, import_react.useState)("");
	const [saving, setSaving] = (0, import_react.useState)(false);
	async function submit(event) {
		event.preventDefault();
		setSaving(true);
		setStatus("");
		try {
			const response = await fetch("/api/activities", {
				method: "PATCH",
				headers: {
					"content-type": "application/json",
					authorization: `Bearer ${accessToken}`
				},
				body: JSON.stringify({
					id: activity.id,
					kind,
					protocol,
					typologyId,
					quantity,
					date,
					time,
					distributionState
				})
			});
			const result = await response.json();
			if (!response.ok) throw new Error(result.error || "Não foi possível atualizar o registro.");
			await onSaved(result.message || "Registro atualizado.");
		} catch (error) {
			setStatus(error instanceof Error ? error.message : "Não foi possível atualizar o registro.");
			setSaving(false);
		}
	}
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: "modal-backdrop",
		role: "presentation",
		onMouseDown: (event) => {
			if (event.target === event.currentTarget) onClose();
		},
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
			className: "panel edit-modal",
			role: "dialog",
			"aria-modal": "true",
			"aria-labelledby": "edit-record-title",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "section-heading",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "eyebrow",
						children: "CORRIGIR REGISTRO"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
						id: "edit-record-title",
						children: "Editar protocolo ou ligação"
					})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						type: "button",
						className: "modal-close",
						onClick: onClose,
						"aria-label": "Fechar",
						children: "×"
					})]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "kind-toggle",
					role: "group",
					"aria-label": "Tipo de atividade",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						type: "button",
						className: kind === "protocol" ? "selected" : "",
						onClick: () => setKind("protocol"),
						children: "Protocolo"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						type: "button",
						className: kind === "call" ? "selected" : "",
						onClick: () => setKind("call"),
						children: "Ligação"
					})]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("form", {
					className: "activity-form",
					onSubmit: submit,
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
							className: "field",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "Tipologia" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("select", {
								value: typologyId,
								onChange: (event) => setTypologyId(Number(event.target.value)),
								required: true,
								children: typologies.map((item) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
									value: item.id,
									children: item.name
								}, item.id))
							})]
						}),
						kind === "protocol" ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
							className: "field",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "Número do protocolo" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
								value: protocol,
								onChange: (event) => setProtocol(event.target.value),
								required: true,
								autoFocus: true
							})]
						}) : null,
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
							className: "field",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "Estado atendido" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("select", {
								value: distributionState,
								onChange: (event) => setDistributionState(event.target.value),
								required: true,
								children: Object.entries(STATE_CONTACTS).map(([code, item]) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
									value: code,
									children: item.state
								}, code))
							})]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "form-row three",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
									className: "field",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "Data" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
										type: "date",
										value: date,
										onChange: (event) => setDate(event.target.value),
										required: true
									})]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
									className: "field",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "Hora" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
										type: "time",
										value: time,
										onChange: (event) => setTime(event.target.value),
										required: true
									})]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
									className: "field",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "Quantidade" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
										type: "number",
										min: "1",
										max: "9999",
										value: quantity,
										onChange: (event) => setQuantity(Number(event.target.value)),
										required: true
									})]
								})
							]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "modal-actions",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
								type: "button",
								className: "secondary-button",
								onClick: onClose,
								children: "Cancelar"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
								type: "submit",
								className: "primary-button",
								disabled: saving,
								children: saving ? "Salvando..." : "Salvar alterações"
							})]
						}),
						status ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "form-status error",
							role: "alert",
							children: status
						}) : null
					]
				})
			]
		})
	});
}
var STATE_CONTACTS = {
	AL: {
		state: "Alagoas",
		whatsapp: "(82) 2126-9200",
		central: "0800 082 0196"
	},
	AP: {
		state: "Amapá",
		whatsapp: "(96) 3082-2949",
		central: "0800 096 0196"
	},
	GO: {
		state: "Goiás",
		whatsapp: "(62) 3243-2020",
		central: "0800 062 0196"
	},
	MA: {
		state: "Maranhão",
		whatsapp: "(98) 2055-0116",
		central: "116"
	},
	PA: {
		state: "Pará",
		whatsapp: "(91) 3217-8200",
		central: "0800 091 0196"
	},
	PI: {
		state: "Piauí",
		whatsapp: "(86) 3228-8200",
		central: "0800 086 0800"
	},
	RS: {
		state: "Rio Grande do Sul",
		whatsapp: "(51) 3382-5500",
		central: "0800 721 2333"
	}
};
function Scripts() {
	const [stateCode, setStateCode] = (0, import_react.useState)("PA");
	const [kind, setKind] = (0, import_react.useState)("immediate");
	const [customerName, setCustomerName] = (0, import_react.useState)("");
	const [sapProtocol, setSapProtocol] = (0, import_react.useState)("");
	const [newContract, setNewContract] = (0, import_react.useState)("");
	const [siteProtocol, setSiteProtocol] = (0, import_react.useState)("");
	const [previousProtocol, setPreviousProtocol] = (0, import_react.useState)("");
	const [denialReason, setDenialReason] = (0, import_react.useState)("");
	const [copied, setCopied] = (0, import_react.useState)(false);
	const contact = STATE_CONTACTS[stateCode];
	const name = customerName.trim().toUpperCase() || "NOME COMPLETO DO CLIENTE";
	const protocol = sapProtocol.trim() || "NÚMERO DO PROTOCOLO SAP";
	const footer = `Estamos à disposição para lhe atender: www.equatorialenergia.com.br, WhatsApp ${contact.whatsapp} e Central de Atendimento ${contact.central}.\n\nConte sempre com a nossa Energia!\n\nEquatorial Energia`;
	const result = {
		immediate: `Olá, ${name}!\n\nRecebemos a sua solicitação de Troca de Titularidade e já registramos em nosso sistema. Sua nova conta contrato ${newContract.trim() || "NOVA CONTA CONTRATO"} marca o início da sua jornada como cliente da Equatorial. O número do seu protocolo de atendimento é ${protocol}.\n\n${footer}`,
		analysis: `Olá, ${name}!\n\nRecebemos a sua solicitação de Troca de Titularidade e já encaminhamos para análise. Se estiver tudo certo, o serviço será realizado em até 3 (três) dias úteis para área urbana ou 5 (cinco) dias úteis para área rural. Orientamos acompanhar o andamento pela Central de Atendimento, site ou agência mais próxima. O número do seu protocolo de atendimento é ${protocol}.\n\n${footer}`,
		denied: `Olá, ${name}!\n\nRecebemos a sua solicitação de Troca de Titularidade, porém ainda não foi possível realizar o atendimento pelo seguinte motivo: ${denialReason.trim().toUpperCase() || "INFORME O MOTIVO DO INDEFERIMENTO"}. Solicite um novo serviço assim que o motivo indicado estiver resolvido. Aguardamos seu retorno!\n\nO número do seu protocolo de atendimento é ${protocol}.\n\n${footer}`,
		reactivation: `Olá, ${name}!\n\nRecebemos a sua solicitação de Troca de Titularidade e já encaminhamos para análise. Se estiver tudo certo, o serviço será realizado em até 3 (três) dias úteis para área urbana ou 5 (cinco) dias úteis para área rural, e a reativação será realizada em até 5 dias úteis. Orientamos acompanhar o andamento pela Central de Atendimento, site ou agência mais próxima. O número do seu protocolo de atendimento é ${protocol}.\n\n${footer}`,
		repeat: `Olá, ${name}!\n\nA sua solicitação de Troca de Titularidade, registrada pelo protocolo do site ${siteProtocol.trim() || "PROTOCOLO DO SITE"}, não foi registrada porque identificamos que já consta uma solicitação pelo protocolo ${previousProtocol.trim() || "PROTOCOLO ANTERIOR"}, que se encontra em andamento. Esta solicitação será classificada como reincidente e será necessário aguardar sua conclusão e comunicação.\n\nO número do seu protocolo de atendimento é ${protocol}.\n\n${footer}`
	}[kind];
	async function copyScript() {
		await navigator.clipboard.writeText(result);
		setCopied(true);
		window.setTimeout(() => setCopied(false), 2200);
	}
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "page-stack scripts-page",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "page-title",
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "eyebrow",
					children: "TEXTOS PADRONIZADOS"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", { children: "Scripts de Troca de Titularidade" }),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", { children: "Selecione o estado e o parecer. Os telefones corretos entram automaticamente." })
			] })
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
			className: "scripts-layout",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "panel scripts-form-panel",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "form-row script-two-columns",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
							className: "field",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "Estado do atendimento" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("select", {
								value: stateCode,
								onChange: (event) => setStateCode(event.target.value),
								children: Object.entries(STATE_CONTACTS).map(([code, item]) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
									value: code,
									children: item.state
								}, code))
							})]
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
							className: "field",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "Tipo de parecer" }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("select", {
								value: kind,
								onChange: (event) => setKind(event.target.value),
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
										value: "immediate",
										children: "Deferido — troca imediata"
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
										value: "analysis",
										children: "Deferido — encaminhado para análise"
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
										value: "denied",
										children: "Indeferido"
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
										value: "reactivation",
										children: "Análise com reativação"
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
										value: "repeat",
										children: "Reincidente"
									})
								]
							})]
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
						className: "field",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "Nome completo do cliente" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
							value: customerName,
							onChange: (event) => setCustomerName(event.target.value),
							placeholder: "Ex.: Antônio dos Santos Sousa"
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
						className: "field",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "Protocolo do SAP" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
							value: sapProtocol,
							onChange: (event) => setSapProtocol(event.target.value),
							placeholder: "Ex.: 65986619"
						})]
					}),
					kind === "immediate" ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
						className: "field",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "Nova conta contrato" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
							value: newContract,
							onChange: (event) => setNewContract(event.target.value),
							placeholder: "Ex.: 3040387519"
						})]
					}) : null,
					kind === "denied" ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
						className: "field",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "Motivo do indeferimento" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("textarea", {
							value: denialReason,
							onChange: (event) => setDenialReason(event.target.value),
							placeholder: "Ex.: Documentação incompleta...",
							rows: 4
						})]
					}) : null,
					kind === "repeat" ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "form-row script-two-columns",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
							className: "field",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "Protocolo do site" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
								value: siteProtocol,
								onChange: (event) => setSiteProtocol(event.target.value)
							})]
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
							className: "field",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "Protocolo anterior em andamento" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
								value: previousProtocol,
								onChange: (event) => setPreviousProtocol(event.target.value)
							})]
						})]
					}) : null,
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "state-contact-card",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("strong", { children: ["Contatos de ", contact.state] }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", { children: ["WhatsApp ", contact.whatsapp] }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", { children: ["Central ", contact.central] })
						]
					})
				]
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("aside", {
				className: "panel script-preview-panel",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "section-heading",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "eyebrow",
							children: "PRONTO PARA USAR"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", { children: "Prévia do script" })] })
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("pre", { children: result }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						className: "primary-button copy-script-button",
						type: "button",
						onClick: () => void copyScript(),
						children: copied ? "Script copiado!" : "Copiar script"
					})
				]
			})]
		})]
	});
}
function Report({ data, isSupervisor }) {
	const [selectedEmail, setSelectedEmail] = (0, import_react.useState)("all");
	const source = isSupervisor && selectedEmail !== "all" ? data.activities.filter((activity) => activity.userEmail === selectedEmail) : data.activities;
	const groups = data.typologies.map((typology) => {
		const items = source.filter((activity) => activity.typologyId === typology.id);
		return {
			name: typology.name,
			total: items.reduce((sum, item) => sum + item.quantity, 0)
		};
	}).filter((item) => item.total > 0).sort((a, b) => b.total - a.total);
	const max = Math.max(1, ...groups.map((item) => item.total));
	const protocolCount = source.filter((item) => item.kind === "protocol").reduce((sum, item) => sum + item.quantity, 0);
	const callCount = source.filter((item) => item.kind === "call").reduce((sum, item) => sum + item.quantity, 0);
	const selectedMember = data.team.find((member) => member.email === selectedEmail);
	const exportOptions = {
		title: isSupervisor ? "Relatório de produtividade da equipe" : "Relatório individual de produtividade",
		subtitle: isSupervisor ? selectedMember?.name ?? "Toda a equipe" : data.currentUser.name,
		activities: source
	};
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "page-stack",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "page-title report-title",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "eyebrow",
						children: "ANÁLISE"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", { children: isSupervisor ? "Relatórios da equipe" : "Meu relatório" }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", { children: isSupervisor ? "Selecione toda a equipe ou um atendente para consultar e exportar." : "Resumo individual dos seus registros realizados no sistema." })
				] }), isSupervisor ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "report-toolbar",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("select", {
						value: selectedEmail,
						onChange: (event) => setSelectedEmail(event.target.value),
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
							value: "all",
							children: "Toda a equipe"
						}), data.team.map((member) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
							value: member.email,
							children: member.name
						}, member.email))]
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "export-actions",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
							type: "button",
							className: "export-button pdf",
							onClick: () => exportPdfReport(exportOptions),
							children: "Baixar PDF"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
							type: "button",
							className: "export-button excel",
							onClick: () => exportExcelReport(exportOptions),
							children: "Baixar Excel"
						})]
					})]
				}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
					className: "permission-tag readonly",
					children: "Visualização individual"
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
				className: "metric-grid report-metrics",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("article", {
						className: "metric-card",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "metric-icon blue",
							children: "▤"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("small", { children: "Protocolos" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("strong", { children: protocolCount })] })]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("article", {
						className: "metric-card",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "metric-icon green",
							children: "◖"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("small", { children: "Ligações" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("strong", { children: callCount })] })]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("article", {
						className: "metric-card",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "metric-icon blue",
							children: "Σ"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("small", { children: "Total" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("strong", { children: protocolCount + callCount })] })]
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
				className: "panel chart-panel",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "section-heading",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "eyebrow",
						children: "DISTRIBUIÇÃO"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", { children: "Quantidade por tipologia" })] })
				}), groups.length ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "bar-chart",
					children: groups.map((item) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "bar-row",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: item.name }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("strong", { children: item.total })] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "bar-track",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { style: { width: `${item.total / max * 100}%` } })
						})]
					}, item.name))
				}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(EmptyState, {
					title: "Sem dados para o relatório",
					text: "Os indicadores serão exibidos após os primeiros registros."
				})]
			})
		]
	});
}
function Team({ data }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "page-stack",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "page-title",
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "eyebrow",
					children: "ACESSO DA SUPERVISÃO"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", { children: "Desempenho da equipe" }),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", { children: "Somente visualização: nenhum registro pode ser criado ou alterado aqui." })
			] })
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(TeamSummary, { data })]
	});
}
function TeamSummary({ data, compact = false }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
		className: `panel team-panel ${compact ? "compact" : ""}`,
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "section-heading",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "eyebrow",
				children: "EQUIPE"
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", { children: "Resultado por atendente" })] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
				className: "permission-tag readonly",
				children: "Somente leitura"
			})]
		}), data.team.length ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "table-scroll",
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("table", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("thead", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("tr", { children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", { children: "Atendente" }),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", { children: "Protocolos" }),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", { children: "Ligações" }),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", { children: "Total" }),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", { children: "Produtividade" })
			] }) }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("tbody", { children: data.team.map((member) => {
				const score = member.productiveSeconds / data.settings.workdaySeconds;
				return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("tr", { children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("td", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("strong", { children: member.name }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("small", { children: member.email })] }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", { children: member.protocols }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", { children: member.calls }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", { children: member.total }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: `score-pill ${score >= .9 ? "good" : "low"}`,
						children: formatPercent(score)
					}) })
				] }, member.email);
			}) })] })
		}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(EmptyState, {
			title: "Nenhum atendente identificado",
			text: "Os atendentes aparecerão depois do primeiro acesso ao sistema."
		})]
	});
}
function EmptyState({ title, text }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "empty-state",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "○" }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("strong", { children: title }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", { children: text })
		]
	});
}
//#endregion
export { Dashboard as default };
