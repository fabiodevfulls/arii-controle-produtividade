export default {
  "bootstrapScriptContent": "import(\"/assets/index-CK4RGPP2.js\")",
  "clientReferenceDeps": {
    "62277abed507": {
      "js": [
        "/assets/dashboard-CwZ6MoNC.js",
        "/assets/rolldown-runtime-S-ySWqyJ.js",
        "/assets/framework-CXnKph_e.js",
        "/assets/index-CK4RGPP2.js"
      ],
      "css": []
    },
    "7065020969b4": {
      "js": [
        "/assets/login-form-CPTkp8Ki.js",
        "/assets/rolldown-runtime-S-ySWqyJ.js",
        "/assets/framework-CXnKph_e.js",
        "/assets/index-CK4RGPP2.js"
      ],
      "css": [
        "/assets/login-form-ZYn1wv7l.css"
      ]
    },
    "9d7895456a8a": {
      "js": [
        "/assets/index-CK4RGPP2.js",
        "/assets/rolldown-runtime-S-ySWqyJ.js",
        "/assets/framework-CXnKph_e.js"
      ],
      "css": []
    },
    "923de45468d3": {
      "js": [
        "/assets/layout-segment-context-CUxU38vV.js",
        "/assets/rolldown-runtime-S-ySWqyJ.js",
        "/assets/index-CK4RGPP2.js",
        "/assets/framework-CXnKph_e.js"
      ],
      "css": []
    },
    "d522787a6e9e": {
      "js": [
        "/assets/index-CK4RGPP2.js",
        "/assets/rolldown-runtime-S-ySWqyJ.js",
        "/assets/framework-CXnKph_e.js"
      ],
      "css": []
    }
  },
  "serverResources": {
    "app/layout.tsx": {
      "js": [],
      "css": [
        "/assets/index-CoJPC7fk.css"
      ]
    },
    "app/login/page.tsx": {
      "js": [],
      "css": [
        "/assets/index-CoJPC7fk.css"
      ]
    }
  }
}