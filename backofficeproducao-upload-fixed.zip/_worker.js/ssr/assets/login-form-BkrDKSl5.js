import { a as require_react, o as __toESM, t as require_jsx_runtime } from "../index.js";
//#region app/login/styles.module.css
var import_react = /* @__PURE__ */ __toESM(require_react(), 1);
var styles_module_default = {
	page: "_page_gkuvg_1",
	card: "_card_gkuvg_2",
	brand: "_brand_gkuvg_3",
	form: "_form_gkuvg_6",
	tabs: "_tabs_gkuvg_11",
	activeTab: "_activeTab_gkuvg_13",
	primary: "_primary_gkuvg_14",
	status: "_status_gkuvg_17"
};
//#endregion
//#region app/login/login-form.tsx
var import_jsx_runtime = require_jsx_runtime();
function LoginForm() {
	const [mode, setMode] = (0, import_react.useState)("login");
	const [status, setStatus] = (0, import_react.useState)("");
	const [saving, setSaving] = (0, import_react.useState)(false);
	async function register(event) {
		event.preventDefault();
		const form = new FormData(event.currentTarget);
		const password = String(form.get("password") ?? "");
		if (password !== String(form.get("confirmPassword") ?? "")) {
			setStatus("As senhas não são iguais.");
			return;
		}
		setSaving(true);
		setStatus("");
		const response = await fetch("/api/auth/register", {
			method: "POST",
			headers: { "content-type": "application/json" },
			body: JSON.stringify({
				name: form.get("name"),
				employeeCode: form.get("employeeCode"),
				email: form.get("email"),
				password
			})
		});
		const result = await response.json();
		setSaving(false);
		if (!response.ok) {
			setStatus(result.error ?? "Não foi possível criar o cadastro.");
			return;
		}
		setStatus(result.message ?? "Cadastro criado. Agora você já pode entrar.");
		setMode("login");
	}
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
		className: styles_module_default.card,
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: styles_module_default.brand,
				children: "ARII"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", { children: "Backoffice Produção" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", { children: mode === "login" ? "Acesse sua área de trabalho." : "Crie seu acesso individual de atendente." })] }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: styles_module_default.tabs,
				role: "tablist",
				"aria-label": "Acesso ao sistema",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					type: "button",
					className: mode === "login" ? styles_module_default.activeTab : "",
					onClick: () => {
						setMode("login");
						setStatus("");
					},
					children: "Entrar"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					type: "button",
					className: mode === "register" ? styles_module_default.activeTab : "",
					onClick: () => {
						setMode("register");
						setStatus("");
					},
					children: "Criar cadastro"
				})]
			}),
			status ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: styles_module_default.status,
				role: "status",
				children: status
			}) : null,
			mode === "login" ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("form", {
				className: styles_module_default.form,
				action: "/api/auth/login",
				method: "post",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", { children: ["E-mail", /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
						name: "email",
						type: "email",
						autoComplete: "username",
						required: true
					})] }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", { children: ["Senha", /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
						name: "password",
						type: "password",
						autoComplete: "current-password",
						required: true
					})] }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						className: styles_module_default.primary,
						type: "submit",
						children: "Entrar"
					})
				]
			}) : /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("form", {
				className: styles_module_default.form,
				onSubmit: register,
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", { children: ["Nome completo", /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
						name: "name",
						minLength: 3,
						maxLength: 120,
						autoComplete: "name",
						required: true
					})] }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", { children: ["Matrícula", /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
						name: "employeeCode",
						minLength: 2,
						maxLength: 40,
						required: true
					})] }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", { children: ["E-mail corporativo", /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
						name: "email",
						type: "email",
						placeholder: "nome@equatorialservicos.com.br",
						autoComplete: "email",
						required: true
					})] }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", { children: ["Senha", /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
						name: "password",
						type: "password",
						minLength: 8,
						maxLength: 128,
						autoComplete: "new-password",
						required: true
					})] }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", { children: ["Confirmar senha", /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
						name: "confirmPassword",
						type: "password",
						minLength: 8,
						maxLength: 128,
						autoComplete: "new-password",
						required: true
					})] }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("small", { children: "Permitido somente e-mail @equatorialservicos.com.br." }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						className: styles_module_default.primary,
						type: "submit",
						disabled: saving,
						children: saving ? "Criando cadastro..." : "Criar meu cadastro"
					})
				]
			})
		]
	});
}
//#endregion
export { LoginForm as default };
