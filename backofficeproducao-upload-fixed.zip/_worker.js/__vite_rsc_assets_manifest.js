export default {
  "bootstrapScriptContent": "import(\"/assets/index-uz7I0RdC.js\")",
  "clientReferenceDeps": {
    "62277abed507": {
      "js": [
        "/assets/dashboard-SkqZEdAq.js",
        "/assets/rolldown-runtime-S-ySWqyJ.js",
        "/assets/framework-CXnKph_e.js",
        "/assets/index-uz7I0RdC.js"
      ],
      "css": []
    },
    "7065020969b4": {
      "js": [
        "/assets/login-form-CPTkp8Ki.js",
        "/assets/rolldown-runtime-S-ySWqyJ.js",
        "/assets/framework-CXnKph_e.js",
        "/assets/index-uz7I0RdC.js"
      ],
      "css": [
        "/assets/login-form-ZYn1wv7l.css"
      ]
    },
    "9d7895456a8a": {
      "js": [
        "/assets/index-uz7I0RdC.js",
        "/assets/rolldown-runtime-S-ySWqyJ.js",
        "/assets/framework-CXnKph_e.js"
      ],
      "css": []
    },
    "923de45468d3": {
      "js": [
        "/assets/layout-segment-context-CR_2m179.js",
        "/assets/rolldown-runtime-S-ySWqyJ.js",
        "/assets/index-uz7I0RdC.js",
        "/assets/framework-CXnKph_e.js"
      ],
      "css": []
    },
    "d522787a6e9e": {
      "js": [
        "/assets/index-uz7I0RdC.js",
        "/assets/rolldown-runtime-S-ySWqyJ.js",
        "/assets/framework-CXnKph_e.js"
      ],
      "css": []
    }
  },
  "serverResources": {
    "app/layout.tsx": {
      "js": [],
      "css": [
        "/assets/index-CLuMZYD0.css"
      ]
    },
    "app/login/page.tsx": {
      "js": [],
      "css": [
        "/assets/index-CLuMZYD0.css"
      ]
    }
  }
}